import { randomInt } from 'node:crypto';

/**
 * Unbiased Fisher-Yates using the OS CSPRNG.
 *
 * `randomInt(0, n)` draws uniformly and rejects out-of-range samples, so
 * there is no modulo bias. Do not replace this with Math.random "temporarily":
 * a predictable shuffle is indistinguishable from a working one right up
 * until someone notices and takes every pot on the site.
 */
export function secureShuffle<T>(arr: readonly T[]): T[] {
  const out = [...arr];
  for (let i = out.length - 1; i > 0; i--) {
    const j = randomInt(0, i + 1);
    const a = out[i]!;
    out[i] = out[j]!;
    out[j] = a;
  }
  return out;
}

/** Deterministic stand-in for tests. Never import this from production code. */
export function seededShuffle<T>(arr: readonly T[], seed: number): T[] {
  let a = seed >>> 0;
  const rng = () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const out = [...arr];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const b = out[i]!;
    out[i] = out[j]!;
    out[j] = b;
  }
  return out;
}
