import type { Card, HandEvent, HandState, LegalActions, VariantId } from '@mixednuts/engine';
import { legalActionsForSeat } from '@mixednuts/engine';
import type { Variant } from '@mixednuts/engine';

/**
 * ============================================================================
 *  THE RULE
 * ============================================================================
 *
 *  `HandState` NEVER leaves the server process. Not in a message, not in a
 *  log line the client can read, not "just for debugging". The only thing
 *  that crosses the wire is a `HandView`, and a HandView is built for exactly
 *  one viewer.
 *
 *  A hidden card is `null` in this file's types. There is no shape here that
 *  can carry another player's hole card, so a leak requires someone to invent
 *  a new message type — which is a reviewable event, not an accident.
 *
 *  Broadcasting one payload to every seat is the single most common way this
 *  goes wrong. `redactHand` takes a viewer for that reason: there is no
 *  "public state" object to accidentally reuse.
 */

/** A card slot: the card itself if this viewer may see it, otherwise null. */
export type CardSlot = Card | null;

export interface SeatView {
  readonly seat: number;
  readonly playerId: string;
  readonly name: string;
  readonly stack: number;
  readonly committedRound: number;
  readonly committedHand: number;
  readonly folded: boolean;
  readonly allIn: boolean;
  /** One slot per hole card. Non-null only where this viewer is entitled. */
  readonly cards: readonly CardSlot[];
  readonly isViewer: boolean;
}

export interface ShowdownLine {
  readonly seat: number;
  readonly shareId: string;
  readonly cards: readonly Card[];
  readonly description: string;
}

export interface HandView {
  readonly handId: string;
  readonly variant: VariantId;
  readonly button: number;
  readonly smallBlind: number;
  readonly bigBlind: number;
  readonly board: readonly Card[];
  readonly pot: number;
  readonly currentBet: number;
  readonly seats: readonly SeatView[];
  readonly actionOn: number | null;
  /** Present only when it is this viewer's turn. */
  readonly legal: LegalActions | null;
  /** Echo back on the action message; stale values are rejected. */
  readonly actionSeq: number;
  readonly status: 'running' | 'complete';
  readonly showdown: readonly ShowdownLine[];
  readonly awards: readonly { seat: number; amount: number; shareId: string }[];
  readonly viewerSeat: number | null;
}

/**
 * Seats whose cards are public. Empty unless the hand reached a showdown;
 * a pot won by everyone folding reveals nothing, which is also why a fold
 * must never be implemented as "show and discard".
 */
export function revealedSeats(state: HandState): Set<number> {
  const out = new Set<number>();
  if (state.status !== 'complete' || state.result?.uncontested !== false) return out;
  for (const e of state.events) if (e.t === 'showdown') out.add(e.seat);
  return out;
}

function cardSlots(
  state: HandState,
  seatIndex: number,
  viewerSeat: number | null,
  revealed: Set<number>,
): CardSlot[] {
  const s = state.seats[seatIndex]!;
  const mine = viewerSeat === seatIndex;
  const open = revealed.has(seatIndex);
  const upcards = new Set(s.upcards);
  return s.hole.map((c, i) => (mine || open || upcards.has(i) ? c : null));
}

/**
 * Build the view for ONE viewer. `viewerSeat` is null for a spectator.
 *
 * Callers must pass the seat of the socket they are about to write to. There
 * is deliberately no cached "last view" to reuse.
 */
export function redactHand(
  state: HandState,
  variant: Variant,
  handId: string,
  viewerSeat: number | null,
  names: ReadonlyMap<string, string>,
  actionSeq: number,
): HandView {
  const revealed = revealedSeats(state);
  const showdown: ShowdownLine[] = [];
  for (const e of state.events) {
    if (e.t === 'showdown') {
      showdown.push({ seat: e.seat, shareId: e.shareId, cards: e.cards, description: e.description });
    }
  }

  const legal =
    state.actionOn !== null && state.actionOn === viewerSeat
      ? legalActionsForSeat(state, variant, state.actionOn)
      : null;

  return {
    handId,
    variant: variant.id,
    button: state.config.buttonSeat,
    smallBlind: state.config.smallBlind,
    bigBlind: state.config.bigBlind,
    board: [...state.board],
    pot: state.seats.reduce((a, x) => a + x.committedHand, 0),
    currentBet: state.currentBet,
    seats: state.seats.map((x, i) => ({
      seat: i,
      playerId: x.playerId,
      name: names.get(x.playerId) ?? x.playerId,
      stack: x.stack,
      committedRound: x.committedRound,
      committedHand: x.committedHand,
      folded: x.folded,
      allIn: x.allIn,
      cards: cardSlots(state, i, viewerSeat, revealed),
      isViewer: viewerSeat === i,
    })),
    actionOn: state.actionOn,
    legal,
    actionSeq,
    status: state.status,
    showdown,
    awards: (state.result?.awards ?? []).map((a) => ({
      seat: a.seat,
      amount: a.amount,
      shareId: a.shareId,
    })),
    viewerSeat,
  };
}

/** Public form of an engine event. Hole cards become counts. */
export type PublicEvent =
  | { t: 'deal-hole'; seat: number; count: number; cards: readonly CardSlot[] }
  | Exclude<HandEvent, { t: 'deal-hole' }>;

export function redactEvent(
  event: HandEvent,
  state: HandState,
  viewerSeat: number | null,
  revealed: Set<number>,
): PublicEvent {
  if (event.t !== 'deal-hole') return event;
  const mine = viewerSeat === event.seat;
  const open = revealed.has(event.seat);
  const upcards = new Set(state.seats[event.seat]?.upcards ?? []);
  const base = state.seats[event.seat]!.hole.length - event.cards.length;
  return {
    t: 'deal-hole',
    seat: event.seat,
    count: event.cards.length,
    cards: event.cards.map((c, i) =>
      mine || open || upcards.has(base + i) || event.visibility === 'up' ? c : null,
    ),
  };
}

/**
 * Last line of defence. Walks a finished view and throws if it carries a card
 * the viewer is not entitled to. Cheap enough to run on every outbound
 * message in development, and the server does exactly that.
 */
export function assertNoLeak(view: HandView, state: HandState): void {
  const revealed = revealedSeats(state);
  for (const s of view.seats) {
    if (s.isViewer) continue;
    const upcards = new Set(state.seats[s.seat]?.upcards ?? []);
    s.cards.forEach((c, i) => {
      if (c === null) return;
      if (revealed.has(s.seat) || upcards.has(i)) return;
      throw new Error(
        `LEAK: seat ${view.viewerSeat ?? 'spectator'} was about to receive a hole card of seat ${s.seat}`,
      );
    });
  }
}

// ---------------------------------------------------------------------------
// Wire messages
// ---------------------------------------------------------------------------
import type { Action } from '@mixednuts/engine';

export type ClientMessage =
  /**
   * MUST be the first message on a connection. Nothing else is accepted until
   * it succeeds, and the identity used from then on is the one the token
   * verifier returns — never a value the client supplied.
   */
  | { type: 'auth'; token: string }
  | { type: 'create-room'; variant: VariantId; bigBlind: number }
  | { type: 'join-room'; code: string }
  | { type: 'leave-room' }
  | { type: 'sit' }
  | { type: 'stand' }
  | { type: 'ready' }
  /**
   * `actionSeq` makes actions idempotent: it must match the seq in the view
   * the player was looking at. A double-click or a click that lands after the
   * state moved on is rejected instead of applied to the wrong spot.
   */
  | { type: 'action'; handId: string; actionSeq: number; action: Action };

/**
 * Session scoring for a friend game.
 *
 * `points` is cumulative net chips across the session. Because every hand
 * conserves chips, the points of everyone who has played MUST sum to zero —
 * see `balanced`. A false there means the books do not add up, which is a bug,
 * not a scoring quirk, and it is surfaced to players rather than hidden.
 */
export interface ScoreEntry {
  readonly playerId: string;
  readonly name: string;
  readonly points: number;
  readonly hands: number;
}

export interface ScoreSnapshot {
  readonly hands: number;
  readonly entries: readonly ScoreEntry[];
  /** Cumulative points after each recorded hand, oldest first. */
  readonly series: readonly { readonly playerId: string; readonly points: readonly number[] }[];
  /** True while every recorded hand summed to zero across its players. */
  readonly balanced: boolean;
}

export interface RoomMember {
  readonly playerId: string;
  readonly name: string;
  readonly seated: boolean;
  readonly stack: number;
}

export type ServerMessage =
  | { type: 'authenticated'; playerId: string; name: string }
  | { type: 'room'; code: string; variant: VariantId; bigBlind: number; host: string; members: RoomMember[]; handsPlayed: number }
  | { type: 'room-closed' }
  | { type: 'scoreboard'; snapshot: ScoreSnapshot }
  | { type: 'state'; view: HandView }
  | { type: 'event'; event: PublicEvent }
  | { type: 'error'; message: string };

const ROOM_CODE = /^[2-9A-HJ-NP-Z]{6}$/;

export function parseClientMessage(raw: unknown): ClientMessage | null {
  if (typeof raw !== 'object' || raw === null) return null;
  const m = raw as Record<string, unknown>;
  switch (m['type']) {
    case 'auth':
      return typeof m['token'] === 'string' && m['token'].length > 0 && m['token'].length < 8192
        ? { type: 'auth', token: m['token'] }
        : null;
    case 'create-room': {
      const bb = m['bigBlind'];
      if (typeof m['variant'] !== 'string') return null;
      if (typeof bb !== 'number' || !Number.isInteger(bb) || bb < 2 || bb > 1_000_000) return null;
      return { type: 'create-room', variant: m['variant'] as VariantId, bigBlind: bb };
    }
    case 'join-room': {
      const code = typeof m['code'] === 'string' ? m['code'].trim().toUpperCase() : '';
      return ROOM_CODE.test(code) ? { type: 'join-room', code } : null;
    }
    case 'leave-room':
      return { type: 'leave-room' };
    case 'sit':
      return { type: 'sit' };
    case 'stand':
      return { type: 'stand' };
    case 'ready':
      return { type: 'ready' };
    case 'action': {
      const a = m['action'] as Record<string, unknown> | undefined;
      if (typeof m['handId'] !== 'string' || typeof m['actionSeq'] !== 'number' || !a) return null;
      const t = a['type'];
      if (t === 'fold' || t === 'check' || t === 'call') {
        return { type: 'action', handId: m['handId'], actionSeq: m['actionSeq'], action: { type: t } };
      }
      if ((t === 'bet' || t === 'raise') && typeof a['to'] === 'number' && Number.isInteger(a['to'])) {
        return {
          type: 'action',
          handId: m['handId'],
          actionSeq: m['actionSeq'],
          action: { type: t, to: a['to'] },
        };
      }
      return null;
    }
    default:
      return null;
  }
}
