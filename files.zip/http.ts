import { createReadStream, existsSync, statSync } from 'node:fs';
import { createServer, type Server } from 'node:http';
import { extname, join, normalize, resolve } from 'node:path';

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webmanifest': 'application/manifest+json',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

/**
 * Plain HTTP server that the WebSocket server upgrades from.
 *
 * Two reasons this exists rather than letting `ws` open its own port:
 *
 *  1. Hosts like Railway route one public port and probe it over HTTP. A
 *     socket-only listener answers those probes with a protocol error and the
 *     deploy is marked unhealthy.
 *  2. Serving the client from the same origin means the page and the socket
 *     share a scheme. On https that makes the socket wss:// automatically,
 *     which is the single most common thing to get wrong when going live: a
 *     browser will not open ws:// from an https page.
 */
export function createHttpServer(staticDir: string | null): Server {
  const root = staticDir ? resolve(staticDir) : null;

  return createServer((req, res) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405).end();
      return;
    }
    const url = new URL(req.url ?? '/', 'http://localhost');

    if (url.pathname === '/healthz') {
      res.writeHead(200, { 'content-type': 'text/plain' }).end('ok');
      return;
    }
    if (!root || !existsSync(root)) {
      res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' }).end('Mixed Nuts server');
      return;
    }

    // normalize() collapses "..", and the prefix check rejects anything that
    // still points outside the build directory.
    const requested = resolve(join(root, normalize(decodeURIComponent(url.pathname))));
    const isInside = requested === root || requested.startsWith(root + '/');
    const file =
      isInside && existsSync(requested) && statSync(requested).isFile()
        ? requested
        : join(root, 'index.html'); // single page app: unknown paths get the shell

    if (!existsSync(file)) {
      res.writeHead(404).end();
      return;
    }
    const type = MIME[extname(file)] ?? 'application/octet-stream';
    const immutable = file.includes('/assets/'); // vite hashes these filenames
    res.writeHead(200, {
      'content-type': type,
      'cache-control': immutable ? 'public, max-age=31536000, immutable' : 'no-cache',
    });
    if (req.method === 'HEAD') {
      res.end();
      return;
    }
    createReadStream(file).pipe(res);
  });
}
